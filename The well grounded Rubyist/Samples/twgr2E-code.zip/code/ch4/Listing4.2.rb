require_relative "stacklike"
class Stack
  include Stacklike
end