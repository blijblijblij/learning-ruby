#!/usr/bin/env ruby

while line = ARGF.gets
 puts line 
end
