#!/usr/bin/env ruby

printf( "Hello, %s", "Matz!" ) # => "Hello, Matz!"
