#!/usr/bin/env ruby
# a nice greeting for Matz
hi = "Hello, Matz!"
puts hi # => Hello, Matz!
