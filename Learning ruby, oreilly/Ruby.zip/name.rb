class Name

  attr_accessor :given_name, :family_name

end
