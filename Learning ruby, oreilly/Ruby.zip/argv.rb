#!/usr/bin/env ruby

ARGV << "sonnet_129.txt"
print while gets
