#!/usr/bin/env ruby

puts "%s, %s!" % [ "Hello", "Matz" ]
