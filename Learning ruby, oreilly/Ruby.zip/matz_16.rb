#!/usr/bin/env ruby

puts "Hello, #{ARGV[0]}!"
