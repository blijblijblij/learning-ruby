#!/usr/bin/env ruby

hamlet = "The slings and arrows of outrageous fortune"
hamlet.scan(/\w+/) # => [ "The", "slings", "and", "arrows", "of", "outrageous", "fortune" ]
