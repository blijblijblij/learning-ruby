#!/usr/bin/env ruby
# a nice greeting for Matz
5.times { print "Hello, Matz! " }
