#!/usr/bin/env ruby

value = 0

if value.zero? then
  puts "value is zero. Did you guess that one?"
end
